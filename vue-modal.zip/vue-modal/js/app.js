var list = [
	{
		title:"吃饭打豆豆",
		isChecked:false //状态为false，为不选中  任务未完成
	},
	{
		title:"妙味课堂",
		isChecked:true   //状态为true，为选中    任务完成
	}
];

new Vue({
	el:".main",
	data:{
		list:list,
		todo:'', //记录输入的值
		edtorTodos:'', //记录正在编辑的数据
		beforeTitle:'' //记录正在编辑数据的title
	},
	computed:{
		number(){
		  return this.list.filter(function(item){
				return !item.isChecked
			}).length
		}
	},
	methods:{
		addTodo(){ //如果函数传值 就获取不到事件对象，需要$event，单独接收事件对象
			this.list.push({ //this指向根实例
				title:this.todo,
				isChecked:false,//添加的内容 默认都是未选中的
			})
			this.todo=""; //输入完清空
		},
		deleteTodo(todo){ //接收传过来的值
			var index = this.list.indexOf(todo);  //在list中查找todo这个值
			this.list.splice(index,1) //删除掉这个值
		},
		edtorTodo(todo){//编辑任务
		    this.beforeTitle = todo.title; //编辑这条title时，提前记录
			this.edtorTodos = todo;
			
		},
		edtorTodoed(todo){ //编辑任务成功
			this.edtorTodos='';
		},
		cancelTodo(todo){ //取消编辑任务
			todo.title = this.beforeTitle;
			 this.edtorTodos='';
		}
	
	},
	directives:{ //自定义指令
		"focus":{
			update(el,binding){ //binding里面有value,是判断表达式值的结果
				if(binding.value){
					el.focus(); //focus 调用原生方法
				}
			}
		}
	}
	
});